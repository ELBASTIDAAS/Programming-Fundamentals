function Hello(name){
console.log("Hello "+ name);
}

function multiplyThree(){
    let number = prompt("Enter number")
    let total = number * 3
    console.log("Result: " + total)
}
multiplyThree()